#define _POSIX_C_SOURCE 200809L

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

long long li[] = {0x10, 0x3, 0x8};


char* Myitoa(int num, char* str)
{
    int i = 0;
    char* p = str;
    char* p1, *p2;
    unsigned long long u = num;

    do
    {
        int rem = u % 10;
        *(p + i++) = (rem > 9) ? (rem - 10) + 'a' : rem + '0';
    } while (u /= 10);

    *(p + i) = '\0';

    p1 = p;
    p2 = p + i - 1;

    while (p1 < p2)
    {
        char tmp = *p1;
        *p1 = *p2;
        *p2 = tmp;
        p1++;
        p2--;
    }
    return p;
}


int main()
{
    char * str = (char *)malloc(100);
    int i = 0;
    for (i = 0; i < 3; i++)
    {
        Myitoa(li[i], str);
        printf("%s\n", str);
    }

    free(str);
    return 0;
}