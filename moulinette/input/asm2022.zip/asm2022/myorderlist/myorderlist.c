#include <stdio.h>


// print a number
// algo de tree
// print list


void orderlist(long long *, int);

long long li[] = {0x10, 0x3, 0x8};

int main() {
    
    orderlist(li, 3);
    // print: "3, 8, 16\n"

    return 0;
}





