#include <stdio.h>

void orderlist(long long *list, int size);

long long li[] = {0x10, 0x3, 0x8};

int main() {
    
    orderlist(li, 3);
    // print: "3, 8, 16\n"

    return 0;
}





