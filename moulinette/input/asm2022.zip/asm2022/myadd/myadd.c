#include <stdio.h>


unsigned long long myadd(unsigned long long, unsigned long long);


int main() {

    printf("myadd(3, 6)=0x%llx\n", myadd(3, 6)); // 
    printf("myadd(-1, 6)=0x%llx\n", myadd(-1, 6)); // 
}




